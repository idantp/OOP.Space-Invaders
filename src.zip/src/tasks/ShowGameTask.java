package tasks;
/*
 * Idan Twito
 * 311125249
 */

import interfaces.LevelInformation;
import interfaces.Task;
import highscorestablep.GameFlow;

import java.util.List;

/**
 * Once "s" is pressed in the menu, this task run the Levels of the Game through highscorestablep.GameFlow it contains.
 * called from highscorestablep.Ass7Game.
 */
public class ShowGameTask implements Task<Void> {
    private GameFlow gameFlow;
    private List<LevelInformation> levels;

    /**
     * constructor.
     *
     * @param gameFlow highscorestablep.GameFlow Object.
     * @param levels   The Game levelsandgame the player will play.
     */
    public ShowGameTask(GameFlow gameFlow, List<LevelInformation> levels) {
        this.gameFlow = gameFlow;
        this.levels = levels;
    }

    /**
     * runs the levelsandgame of the Game.
     *
     * @return null.
     */
    public Void run() {
        this.gameFlow.runLevels(this.levels);
        return null;
    }
}
