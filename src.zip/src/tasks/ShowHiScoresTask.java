package tasks;
/*
 * Idan Twito
 * 311125249
 */

import animations.AnimationRunner;
import animations.KeyPressStoppableAnimation;
import biuoop.KeyboardSensor;
import interfaces.Animation;
import interfaces.Task;

/**
 * Once "h" is pressed in the menu, this task run the interfaces.Animation it contains. called from levelsandgame.
 * Ass7Game.
 */
public class ShowHiScoresTask implements Task<Void> {
    private AnimationRunner runner;
    private Animation highScoresAnimation;
    private KeyboardSensor keyboard;

    /**
     * Constructor.
     *
     * @param runner              the interfaces.Animation Runner that runs highScoresAnimation.
     * @param highScoresAnimation the interfaces.Animation we'd like to run.
     * @param keyboard            the keyboard.
     */
    public ShowHiScoresTask(AnimationRunner runner, Animation highScoresAnimation, KeyboardSensor keyboard) {
        this.runner = runner;
        this.keyboard = keyboard;
        this.highScoresAnimation = highScoresAnimation;
    }

    /**
     * runs this interfaces.Animation.
     *
     * @return null.
     */
    public Void run() {

        this.runner.run(new KeyPressStoppableAnimation(keyboard, keyboard.SPACE_KEY, this.highScoresAnimation));
        return null;
    }

}
