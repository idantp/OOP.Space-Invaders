package geometricshapes;
/*
 * Idan Twito
 * 311125249
 */

import java.awt.Color;

import biuoop.DrawSurface;
import interfaces.Sprite;
import levelsandgame.GameEnvironment;
import levelsandgame.GameLevel;

/**
 * geometricshapes.Ball describes geometricshapes.Ball object. geometricshapes.Ball contains its center
 * geometricshapes.Point, radius,color and also the screen coordinates.
 *
 * @ 26.03.18
 * @ Last Updated 21.05.18
 * @ author: Idan Twito
 */
public class Ball implements Sprite {

    //screen sizes
    public static final int WIDTH = 800;
    public static final int HEIGHT = 600;
    public static final int ZERO_PIXEL = 0;
    public static final int SLEEP_TIME = 50;
    //contains the coordinates of the circle's center
    private Point center;
    //the radius
    private int r;
    //color of the ball.
    private Color color;
    private Velocity v;
    //the borders of the screen/frames that the ball wont get out of them
    private int topBorder;
    private int lowerBorder;
    private int rightBorder;
    private int leftBorder;
    private GameEnvironment gameEnvironment;
    private boolean playerBullet;

    /**
     * constructor of geometricshapes.Ball.
     *
     * @param center - center of the ball
     * @param r      - radius of the ball
     * @param color  - the color of the ball
     */
    public Ball(Point center, int r, java.awt.Color color) {
        this.center = center;
        this.r = r;
        this.color = color;
    }

    /**
     * second constructor of geometricshapes.Ball.
     *
     * @param center      - center of the ball.
     * @param r           - radius.
     * @param color       - color of the ball.
     * @param topBorder   - top border of the frame/screen.
     * @param lowerBorder - lower border of the frame/screen.
     * @param rightBorder - right border of the frame/screen.
     * @param leftBorder  -  left border of the frame/screen.
     */
    public Ball(Point center, int r, java.awt.Color color, int topBorder, int lowerBorder, int rightBorder,
                int leftBorder) {
        this.center = center;
        this.r = r;
        this.color = color;
        this.topBorder = topBorder;
        this.lowerBorder = lowerBorder;
        this.leftBorder = leftBorder;
        this.rightBorder = rightBorder;
    }

    /**
     * third constructor of geometricshapes.Ball.
     *
     * @param center       - center of the ball.
     * @param r            - radius.
     * @param color        - color of the ball.
     * @param gEnvironment - the game environment of the ball.
     */
    public Ball(Point center, int r, java.awt.Color color, GameEnvironment gEnvironment) {
        this.center = center;
        this.r = r;
        this.color = color;
        this.gameEnvironment = gEnvironment;
    }

    /**
     * setting new ball with center point only.
     *
     * @param x1 - x coordinate of the ball's center
     * @param y1 - y coordinate of the ball's center
     */
    public Ball(double x1, double y1) {
        this.center = new Point(x1, y1);
    }

    /**
     * setting the given game environment to this ball.
     *
     * @param environment the given game environment
     */
    public void setGameEnvironment(GameEnvironment environment) {
        this.gameEnvironment = environment;
    }

    /**
     * the function returns the top border of the ball.
     *
     * @return (int value) top border
     */
    public int getTopBorder() {
        return this.topBorder;
    }

    /**
     * the function returns the lower border of the ball.
     *
     * @return (int value) lower border
     */
    public int getLowerBorder() {
        return this.lowerBorder;
    }

    /**
     * the function returns the right border of the ball.
     *
     * @return (int value) right border
     */
    public int getRightBorder() {
        return this.rightBorder;
    }

    /**
     * the function returns the left border of the ball.
     *
     * @return (int value) left border
     */
    public int getLeftBorder() {
        return this.leftBorder;
    }

    /**
     * setting velocity for the ball.
     *
     * @param velocity geometricshapes.Velocity.
     */
    public void setVelocity(Velocity velocity) {
        this.v = velocity;
    }

    /**
     * second way to set velocity to ball.
     *
     * @param dx - the movement in x axle
     * @param dy - the movement in y axle
     */
    public void setVelocity(double dx, double dy) {
        this.v = new Velocity(dx, dy);
    }

    /**
     * getting the velocity of certain ball.
     *
     * @return this.v
     */
    public Velocity getVelocity() {
        return this.v;
    }


    /**
     * this function is responsible of moving the ball inside the animation. if the ball does not face any
     * obstacles it will move as declared in the its velocity. otherwise - if a collision found - we get the
     * ball closer to the obstacle and we change the ball's geometricshapes.Velocity accordingly.
     *
     * @param dt specifies the amount of seconds passed since the last call
     */
    public void moveOneStep(double dt) {
        //the ball's velocity depends on the dt (1/60 - 1/frame-rate)
        Velocity velocity = new Velocity(getVelocity().getDx() * dt, getVelocity().getDy() * dt);
        //this line predicts the course movement of the ball
        Line trajectory = new Line(this.center, velocity.applyToPoint(this.center));
        //gets the information about the closest colliding point, if there isn't one - gets null
        CollisionInfo collidingPointInfo = this.gameEnvironment.getClosestCollision(trajectory);
        Rectangle collidingRectangle;
        //if no collision found:
        if (collidingPointInfo == null) {
            //move the ball
            this.center = velocity.applyToPoint(this.center); // this.getVelocity().applyToPoint(this.center);
        } else {
            //double a = this.getVelocity().getDx() / Math.abs(this.getVelocity().getDx());
            //double b = this.getSize() * (-(this.getVelocity().getDx() / Math.abs(this.getVelocity().getDx())));
            //setting the movement of the ball by get it closer the borders.
            //if there was a collision and the geometricshapes.Velocity is not vertical.
            if (this.getVelocity().getDx() != 0) {
                this.center = new Point(collidingPointInfo.collisionPoint().getX() - this.getSize()
                        * (this.getVelocity().getDx() / Math.abs(this.getVelocity().getDx())),
                        collidingPointInfo.collisionPoint().getY() - (this.getSize())
                                * (this.getVelocity().getDy() / Math.abs(this.getVelocity().getDy())));
            } else {
                this.center = new Point(collidingPointInfo.collisionPoint().getX() - this.getSize(),
                        collidingPointInfo.collisionPoint().getY() - (this.getSize())
                                * (this.getVelocity().getDy() / Math.abs(this.getVelocity().getDy())));
            }
            //setting the new velocity once we got a hit.
            this.setVelocity(collidingPointInfo.collisionObject().hit(this, collidingPointInfo.collisionPoint(),
                    this.getVelocity()));
            collidingRectangle = collidingPointInfo.collisionObject().getCollisionRectangle();
            //if the ball gets inside the paddle from the sides make a correction
            if (this.center.getX() > collidingRectangle.getUpperLeft().getX()
                    && this.center.getX() < collidingRectangle.getUpperRight().getX()
                    && this.center.getY() > collidingRectangle.getUpperRight().getY()
                    && this.center.getY() < collidingRectangle.getLowerLeft().getY()) {
                //if the ball got inside the paddle from the left
                if ((int) ((this.center.distance(collidingRectangle.getUpperLeft())))
                        < (int) (this.center.distance(collidingRectangle.getUpperRight()))) {
                    //change the center of the ball so it wont stuck in the paddle
                    Point p = new Point((this.center.getX() - 20), this.center.getY() - 5);
                    this.center = p;
                } else {
                    //change the center of the ball so it wont stuck in the paddle
                    Point p = new Point((this.center.getX() + 20), this.center.getY() - 5);
                    this.center = p;
                }
            }
        }
    }

    /**
     * returning the x coordinate of the ball's center.
     *
     * @return (int value)
     */
    public int getX() {
        return (int) (this.center.getX());

    }

    /**
     * returning the y coordinate of the ball's center.
     *
     * @return (int value)
     */
    public int getY() {
        return (int) (this.center.getY());
    }

    /**
     * returning the size of the ball's radius.
     *
     * @return (int value)
     */
    public int getSize() {
        return this.r;
    }

    /**
     * returning the color the ball.
     *
     * @return this.color.
     */
    public java.awt.Color getColor() {
        return this.color;
    }

    /**
     * returns whether this Ball is the Player's bullet (Ball).
     *
     * @return boolean this.playerBullet
     */
    public boolean playersBullet() {
        return this.playerBullet;
    }

    /**
     * Sets this Ball as the Player's bullet (Ball).
     *
     * @param bullet boolean
     */
    public void setPlayerBullet(boolean bullet) {
        this.playerBullet = bullet;
    }

    /**
     * the function fills the ball with the given color.
     *
     * @param surface - drawing surface.
     */
    public void drawOn(DrawSurface surface) {
        surface.setColor(this.color);
        surface.fillCircle(this.getX(), this.getY(), this.r);
        surface.setColor(Color.BLACK);
        surface.drawCircle(this.getX(), this.getY(), this.r);
    }

    /**
     * notify the ball that time has passed and it should make a new movement.
     *
     * @param dt specifies the amount of seconds passed since the last call
     */
    public void timePassed(double dt) {
        this.moveOneStep(dt);
    }

    /**
     * the function adds this ball to the given game.
     *
     * @param g - the given game we want the ball to be added to
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
    }

    /**
     * removes the geometricshapes.Ball from the lists that contain all the sprites in the given game.
     *
     * @param game the given game we want to remove this geometricshapes.Ball from
     */
    public void removeFromGame(GameLevel game) {
        game.removeSprite(this);
    }
}
