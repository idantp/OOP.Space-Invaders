package geometricshapes;

import java.util.ArrayList;
import java.util.List;

/**
 * geometricshapes.Line describes geometricshapes.Line object. A geometricshapes.Line contain start, end Points.
 *
 * @ 26.03.18
 * @ Update: 20.04.18
 * @ Last Update: 21.05.18
 * @ author: Idan Twito
 */
public class Line {
    //the members of geometricshapes.Line
    private Point start;
    private Point end;

    /**
     * the constructor of geometricshapes.Line.
     *
     * @param start geometricshapes.Point - the start geometricshapes.Point of line
     * @param end   geometricshapes.Point - the end geometricshapes.Point of line
     */
    public Line(Point start, Point end) {
        // constructors
        this.start = start;
        this.end = end;
    }

    /**
     * defining start and end geometricshapes.Point.
     *
     * @param x1 - the x coordinate of start geometricshapes.Point
     * @param y1 - the y coordinate of start geometricshapes.Point
     * @param x2 - the x coordinate of end geometricshapes.Point
     * @param y2 - the y coordinate of end geometricshapes.Point
     */
    public Line(double x1, double y1, double x2, double y2) {
        this.start = new Point(x1, y1);
        this.end = new Point(x2, y2);
    }

    /**
     * @return double variable - the length of the line.
     */
    public double length() {
        return this.start.distance(this.end);
    }

    /**
     * The function retuns the middle point of a line.
     *
     * @return geometricshapes.Point midPoint - the middle point of a line
     */
    public Point middle() {
        double midX;
        double midY;
        //if the line is a point so set the middle point as the points itself
        if (this.start() == this.end()) {
            return this.start();
        }
        //calculating the x coordinate of the middle point
        midX = (this.start.getX() - this.end.getX()) / 2;
        //calculating the y coordinate of the middle point
        midY = (this.start.getY() - this.end.getY()) / 2;
        //making sure that the coordinates are positive so the final calculation wont have mistakes
        if (midX < 0) {
            midX = midX * (-1);
        }
        if (midY < 0) {
            midY = midY * (-1);
        }
        //adding each coordinate (the smaller one) midX value
        if (this.start.getX() > this.end.getX()) {
            midX = this.end.getX() + midX;
        } else {
            midX = this.start.getX() + midX;
        }
        if (this.start.getY() > this.end.getY()) {
            midY = this.end.getY() + midY;
        } else {
            midY = this.start.getY() + midY;
        }
        //setting and returning the middle point.
        Point midPoint = new Point(midX, midY);
        return midPoint;
    }

    /**
     * The function retuns the start point of a line - the point which has the smallest X value.
     *
     * @return geometricshapes.Point - the start point of a line
     */
    public Point start() {
        if (this.start.equals(this.end)) {
            return this.start;
        }
        if (this.start.getX() < this.end.getX()) {
            return this.start;
        } else if (this.start.getX() == this.end.getX()) {
            if (this.start.getY() < this.end.getY()) {
                return this.start;
            } else {
                return this.end;
            }
        } else {
            return this.end;
        }
    }

    /**
     * The function retuns the end point of a line - the point which has the biggest X value.
     *
     * @return geometricshapes.Point - the end point of a line
     */
    public Point end() {
        if (this.start.equals(this.end)) {
            return this.end;
        }
        if (this.start.getX() < this.end.getX()) {
            return this.end;
        } else if (this.start.getX() == this.end.getX()) {
            if (this.start.getY() < this.end.getY()) {
                return this.end;
            }
        } else {
            return this.start;
        }
        return this.start;
    }

    /**
     * The function returns true if the line is horizontal or and false if not.
     *
     * @return boolean - true or false.
     */
    public boolean isHorizontal() {
        return (this.start.getY() == this.end.getY());
    }

    /**
     * The function returns true if the line is vertical or and false if not.
     *
     * @return boolean - true if vertical, false otherwise.
     */
    public boolean isVertical() {
        return (this.start.getX() == this.end.getX());
    }

    /**
     * The function checks whether the given line(this) intersects the line "other".
     * If they do - return True, otherwise - False.
     *
     * @param other (geometricshapes.Line) - the second line to check the intersection
     * @return boolean - true of there's an intersection, false otherwise.
     */
    public boolean isIntersecting(Line other) {
        //declaring X's and Y's coordinates of starts and end points of each line.
        double thisX1 = this.start().getX();
        double thisX2 = this.end().getX();
        double thisY1 = this.start().getY();
        double thisY2 = this.end().getY();
        double otherX1 = other.start().getX();
        double otherX2 = other.end().getX();
        double otherY1 = other.start().getY();
        double otherY2 = other.end().getY();
        //gets the slope of the first line "this"
        double thisSlope;
        //gets the slope of the second line "other"
        double otherSlope;
        //gets the intersection point of Y axis and "this" line
        double thisInterY;
        //gets the intersection point of Y axis and "other" line
        double otherInterY;
        //gets the X coordinate of "this" and "other" lines intersection point
        double xLinesIntersection;
        //gets the Y coordinate of "this" and "other" lines intersection point
        double yLinesIntersection;
        //if the lines are the same ones return false.
        if (this.start().equals(other.start()) && this.end().equals(other.end())) {
            return false;
        }
        //if the two "lines" are points and are the same one's - return false.
        if (this.start().equals(this.end()) && other.start().equals(other.end())
                && this.start().equals(other.start())) {
            return false;
        } else if (this.start().equals(this.end()) && other.start().equals(other.end())) {
            //if the 2 lines are 2 different points return false.
            return false;
        }
        //if the two lines are vertical return false
        if (this.isVertical() && other.isVertical()) {
            return false;
        } else if (this.isHorizontal() && other.isHorizontal()) {
            //if the two lines are horizontal return false
            return false;
        }
        //finding the current line's slope
        thisSlope = (this.start.getY() - this.end.getY()) / (this.start.getX() - this.end.getX());
        //finding the other line's slope
        otherSlope = (other.start.getY() - other.end.getY()) / ((other.start.getX() - other.end.getX()));
        //if the lines have the same slope  - they don't intersect
        if (thisSlope == otherSlope) {
            return false;
        }
        //finding the current line's intersection with y
        thisInterY = (thisSlope * ((-1) * this.start.getX())) + this.start.getY();
        //finding the other line's intersection with y.
        otherInterY = (otherSlope * ((-1) * other.start.getX())) + other.start.getY();
        //if the first line is vertical but the second isnt:
        if (this.isVertical() && !(other.isVertical())) {
            //define x,y coordinates of the intersection point
            xLinesIntersection = this.start().getX();
            yLinesIntersection = (otherSlope * xLinesIntersection) + otherInterY;
            //if the first line isnt vertical but the second is vertical:
        } else if (!(this.isVertical()) && other.isVertical()) {
            //define x,y coordinates of the intersection point
            xLinesIntersection = other.start().getX();
            yLinesIntersection = (thisSlope * xLinesIntersection) + thisInterY;
            //if both lines aren't vertical:
        } else {
            //finding the x coordinate of the intersection point
            xLinesIntersection = (otherInterY - thisInterY) / (thisSlope - otherSlope);
            //finding the y coordinate of the intersection point
            yLinesIntersection = (thisSlope * xLinesIntersection) + thisInterY;
        }
        /*
         * if the x,y coordinates of the intersection point are between the start and the end points
         * of both lines - return true, otherwise - false.
         */
        if ((xLinesIntersection >= thisX1 && xLinesIntersection <= thisX2)
                && (yLinesIntersection >= thisY1 && yLinesIntersection <= thisY2
                || yLinesIntersection <= thisY1 && yLinesIntersection >= thisY2)
                && (xLinesIntersection >= otherX1 && xLinesIntersection <= otherX2)
                && ((yLinesIntersection >= otherY1 && yLinesIntersection <= otherY2)
                || (yLinesIntersection <= otherY1 && yLinesIntersection >= otherY2))) {
            return true;
        }
        return false;
    }

    // Returns the intersection point if the lines intersect,
    // and null otherwise.

    /**
     * The function finds and returns the intersection point of two lines (if there is an existing one).
     *
     * @param other (geometricshapes.Line) - the second line to check the intersection
     * @return geometricshapes.Point intersectionP - the intersection point, or null if there is no intersection.
     */
    public Point intersectionWith(Line other) {
        double thisSlope;
        double otherSlope;
        double thisInterY;
        double otherInterY;
        double xLinesIntersection;
        double yLinesIntersection;
        Point intersectionP;
        if (!this.isIntersecting(other)) {
            return null;
        } else {
            //if the "lines" are the same point - return the intersection point as one of the points
            if (this.start().equals(this.end()) && other.start().equals(other.end())
                    && this.start().equals(other.start())) {
                return this.start();
            }
            //finding the current line's slope
            thisSlope = (this.start.getY() - this.end.getY()) / (this.start.getX() - this.end.getX());
            //finding the other line's slope
            otherSlope = (other.start.getY() - other.end.getY()) / ((other.start.getX() - other.end.getX()));

            //finding the current line's intersection with y
            thisInterY = (thisSlope * ((-1) * this.start.getX())) + this.start.getY();
            //finding the other line's intersection with y.
            otherInterY = (otherSlope * ((-1) * other.start.getX())) + other.start.getY();
            if (this.isVertical() && !(other.isVertical())) {
                xLinesIntersection = this.start().getX();
                yLinesIntersection = (otherSlope * xLinesIntersection) + otherInterY;
            } else if (!(this.isVertical()) && other.isVertical()) {
                xLinesIntersection = other.start().getX();
                yLinesIntersection = (thisSlope * xLinesIntersection) + thisInterY;
            } else {
                xLinesIntersection = (otherInterY - thisInterY) / (thisSlope - otherSlope);
                //finding the y coordinate of the intersection point
                yLinesIntersection = (thisSlope * xLinesIntersection) + thisInterY;
            }
            intersectionP = new Point(xLinesIntersection, yLinesIntersection);
            return intersectionP;
        }
    }

    // equals -- return true is the lines are equal, false otherwise

    /**
     * checks whether two lines are equal and returns true if they do, false otherwise.
     *
     * @param other - the second line to check the equality
     * @return true - if the lines equal, false otherwise.
     */
    public boolean equals(Line other) {
        //checking the equality
        if ((this.start.equals(other.start) && this.end.equals(other.end))
                || (this.start.equals(other.end) && this.end.equals(other.start))) {
            return true;
        }
        return false;
    }

    /**
     * if this line intersects the given rectangle, the function returns the closest intersection point to the
     * start of the line. If they dont intersect return null.
     *
     * @param rect geometricshapes.Rectangle we want to check the intersection with
     * @return closestPoint geometricshapes.Point if the shapes intersect, null otherwise.
     */
    public Point closestIntersectionToStartOfLine(Rectangle rect) {
        //list of points
        List<Point> intersectionPointsList = new ArrayList<Point>();
        //the list gets all the intersection points of the line with the rectangle
        intersectionPointsList = rect.intersectionPoints(this);
        //will get the closest intersection point if it exists
        Point closestPoint;
        double distance;
        //if no points were found return null.
        if (intersectionPointsList.isEmpty()) {
            return null;
        } else {
            //gets the distance between the start of the line and the first intersection point
            distance = this.start().distance(intersectionPointsList.get(0));
            //gets the first intersection point
            closestPoint = new Point(intersectionPointsList.get(0).getX(), intersectionPointsList.get(0).getY());
            //running over all the intersection points
            for (int i = 0; i < intersectionPointsList.size(); i++) {
                /*
                 * if the distance between the current intersection point of the list and the start point of the line
                 * is smaller the the previous smallest distance:
                 */
                if (this.start().distance(intersectionPointsList.get(i)) < distance) {
                    //set the new smallest distance
                    distance = this.start().distance(intersectionPointsList.get(i));
                    //set the new closestPoint
                    closestPoint = new Point(intersectionPointsList.get(i).getX(),
                            intersectionPointsList.get(i).getY());
                }
            }
        }
        return closestPoint;
    }

    /**
     * checks whether the given point intersects this line.
     *
     * @param p geometricshapes.Point variable we want to check if it intersects this line
     * @return true if they intersects, false otherwise.
     */
    public boolean isPointIntersectLine(Point p) {
        /*
         *in triangle every side is smaller than the sum of the other 2 sides. according to this sentence we
         * check of the point located on the line.
         */
        return ((p.distance(this.start()) + p.distance(this.end())) == this.length());
    }

}
