package blockandpaddle;
/*
 * Idan Twito
 * 311125249
 */

import indicators.Counter;

/**
 * once the Spacecraft (the Player) was hit, we remove the Paddle, and reduce the lives Counter by 1.
 */
public class SpaceRemover {
    private Counter lives;

    /**
     * Constructor.
     *
     * @param counter counts the lives number
     */
    public SpaceRemover(Counter counter) {
        this.lives = counter;
    }

    /**
     * once a hit happened reduce the lives Counter by 1.
     */
    public void hit() {
        if ((lives != null)) {
            lives.decrease(1);
        }
    }
}
