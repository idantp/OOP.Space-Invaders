package blockandpaddle;
/*
 * Idan Twito
 * 311125249
 */

import biuoop.DrawSurface;
import geometricshapes.Point;
import geometricshapes.Ball;
import geometricshapes.Rectangle;
import geometricshapes.Velocity;
import geometricshapes.Line;
import interfaces.Collidable;
import interfaces.HitListener;
import interfaces.HitNotifier;
import interfaces.Sprite;
import levelsandgame.GameLevel;

import java.awt.Color;
import java.awt.Image;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * blockandpaddle.Block is the Obstacle on the screen. it's initialized with a geometricshapes.Rectangle,
 * Color and blockLife. It implements interfaces.Collidable and interfaces.Sprite. when the geometricshapes.
 * Ball of the game hits a blockandpaddle.Block the geometricshapes.Ball changes its geometricshapes.Velocity.
 *
 * @ 20.04.18
 * @ last update: 21.05.18
 * @ author: Idan Twito
 */
public class Block implements Collidable, Sprite, HitNotifier {
    //the members of block
    private Rectangle rectangle;
    private Color color;
    private int blockLife;
    //an array that contains all the blockandpaddle.Block that want to be notified of hit events
    private List<HitListener> hitListeners;
    private boolean shieldBoolean;

    /**
     * constructor of this class.
     *
     * @param rectangle each block will be rectangle
     * @param color     specifies the color of the block
     * @param blockLife indicates the block "life/health", every time a ball hits a block the same block's health
     *                  decreases by 1 until it gets to 0. Each block's life will be shown on the block,
     *                  but if a certain block initialized with 0 blockLife 'X' will
     *                  be shown on the block.
     */
    public Block(Rectangle rectangle, Color color, int blockLife) {
        this.rectangle = rectangle;
        this.color = color;
        this.blockLife = blockLife;
        //an array that contains all the blockandpaddle.Block that want to be notified of hit events
        this.hitListeners = new ArrayList<HitListener>();
    }


    /**
     * Constructor.
     */
    public Block() {
    }

    /**
     * constructor of this class.
     *
     * @param imageMap  image that can describe the blockandpaddle.Block's background.
     * @param rectangle each block will be rectangle
     * @param colorMap  specifies the color of the block
     * @param blockLife indicates the block "life/health", every time a ball hits a block the same block's health
     *                  decreases by 1 until it gets to 0. Each block's life will be shown on the block,
     *                  but if a certain block initialized with 0 blockLife 'X' will
     *                  be shown on the block.
     */
    public Block(Rectangle rectangle, Map<Integer, Image> imageMap, Map<Integer, Color> colorMap, int blockLife) {
        this.rectangle = rectangle;
        this.blockLife = blockLife;
        //an array that contains all the blockandpaddle.Block that want to be notified of hit events
        this.hitListeners = new ArrayList<HitListener>();
    }

    /**
     * constructor of this class.
     *
     * @param rectangle     each block will be rectangle
     * @param color         specifies the color of the block
     * @param shieldBoolean if this Block is a Shield gets True.
     */
    public Block(Rectangle rectangle, Color color, boolean shieldBoolean) {
        this.shieldBoolean = shieldBoolean;
        this.rectangle = rectangle;
        this.color = color;
        //an array that contains all the blockandpaddle.Block that want to be notified of hit events
        this.hitListeners = new ArrayList<HitListener>();
    }

    /**
     * setting a stroke color to this blockandpaddle.Block.
     *
     * @param strokeColor Color
     */
    public void addStrokeToBlock(Color strokeColor) {
        this.color = this.color;
    }

    /**
     * returns the shape (rectangle) of the block.
     *
     * @return geometricshapes.Rectangle this.rectangle
     */
    public Rectangle getCollisionRectangle() {
        return this.rectangle;
    }

    /**
     * verifies whether this Block is a Shield or not.
     *
     * @return true if its a shield, otherwise false
     */
    public boolean isShield() {
        return shieldBoolean;
    }

    /**
     * given there was a collision of an object with this block, the function returns the new velocity
     * of the colliding object after the hit with this block.
     *
     * @param collisionPoint  geometricshapes.Point that describes the collision point.
     * @param currentVelocity geometricshapes.Velocity - the current velocity of the colliding object.
     * @param hitter          - the geometricshapes.Ball that is involved in the this hit.
     * @return the velocity after the collision
     */
    public Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity) {
        //declaring the sides of the rectangle
        Line upperL = this.rectangle.getUpperLine();
        Line lowerL = this.rectangle.getLowerLine();
        Line rightL = this.rectangle.getRightLine();
        Line leftL = this.rectangle.getLeftLine();
        if (this.blockLife > 0) {
            this.blockLife--;
        }

        //the new velocity we'll return
        Velocity newVelocity = currentVelocity;
        //if there was a hit in the upper or lower side - the new velocity gets the vertical previous velocity
        if (upperL.isPointIntersectLine(collisionPoint) || lowerL.isPointIntersectLine(collisionPoint)) {
            newVelocity = new Velocity(currentVelocity.getDx(), (currentVelocity.getDy() * (-1)));
        }
        //if there was a hit in the left or right side - the new velocity gets the horizontal previous velocity
        if (leftL.isPointIntersectLine(collisionPoint)
                || rightL.isPointIntersectLine(collisionPoint)) {
            newVelocity = new Velocity((currentVelocity.getDx() * (-1)), (currentVelocity.getDy()));
        }
        //notifies a hit occured with that ball and this blockandpaddle.Block
        this.notifyHit(hitter);
        return newVelocity;
    }

    /**
     * this function draws this block.
     *
     * @param surface - the surface we want to draw on
     */
    public void drawOn(DrawSurface surface) {
        surface.setColor(this.color);
        surface.fillRectangle((int) rectangle.getUpperLeft().getX(),
                (int) rectangle.getUpperLeft().getY(), (int) rectangle.getWidth(), (int) rectangle.getHeight());

    }


    /**
     * tells the block the time has passed.
     *
     * @param dt specifies the amount of seconds passed since the last call
     */
    public void timePassed(double dt) {
    }

    /**
     * this function adds this block to the given game.
     *
     * @param g - the game that we want to add this block to.
     */
    public void addToGame(GameLevel g) {
        g.addCollidable(this);
        g.addSprite(this);
    }

    /**
     * removes the blockandpaddle.Block from the lists that contain all the sprites and the collidables
     * in the given game.
     *
     * @param game the given game we want to remove this blockandpaddle.Block from
     */
    public void removeFromGame(GameLevel game) {
        game.removeCollidable(this);
        game.removeSprite(this);
    }

    /**
     * add a new blockandpaddle.Block that implements interfaces.HitListener to the hitListeners list.
     *
     * @param hl an Object that is notified of hit events
     */
    public void addHitListener(HitListener hl) {
        this.hitListeners.add(hl);
    }

    /**
     * remove the blockandpaddle.Block that implements interfaces.HitListener from the hitListeners list.
     *
     * @param hl an Object that is notified of hit events
     */
    public void removeHitListener(HitListener hl) {
        this.hitListeners.remove(hl);
    }

    /**
     * will be called whenever a hit() occurs, and notifies all of the registered interfaces.HitListener
     * objects by calling their hitEvent method.
     *
     * @param hitter the geometricshapes.Ball which is involved in the hit.
     */
    private void notifyHit(Ball hitter) {
        // Make a copy of the hitListeners before iterating over them.
        List<HitListener> listeners = new ArrayList<HitListener>(this.hitListeners);
        // Notify all listeners about a hit event with the given hitter geometricshapes.
        // Ball and this blockandpaddle.Block:
        for (HitListener hl : listeners) {
            hl.hitEvent(this, hitter);
        }
    }

    /**
     * getting the width of the given blockandpaddle.Block.
     *
     * @return int this.rectangle.getWidth()
     */
    public double getWidth() {
        return this.rectangle.getWidth();
    }

    /**
     * returns this blockandpaddle.Block's life/points.
     *
     * @return this.blockLife
     */
    public int getHitPoints() {
        return this.blockLife;
    }
}