package blockandpaddle;
/*
 * Idan Twito
 * 311125249
 */

import geometricshapes.Ball;
import geometricshapes.Point;

import java.awt.Color;

/**
 * this Class extends and defines the Bullet(Balls) of the Player the are shot towards the Aliens.
 */
public class PlayerBullet extends Ball {

    /**
     * Constructor extends Ball.
     *
     * @param xCoordinate the x Coordinate of the Ball's Center Points.
     * @param yCoordinate the y Coordinate of the Ball's Center Points.
     */
    public PlayerBullet(int xCoordinate, int yCoordinate) {
        super(new Point(xCoordinate, yCoordinate), 5, Color.WHITE);
        this.setVelocity(0, -475);
    }

}
