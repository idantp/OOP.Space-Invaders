package blockandpaddle;
/*
 * Idan Twito
 * 311125249
 */

import spaceinvaders.AliensCollection;
import geometricshapes.Ball;
import indicators.Counter;
import interfaces.HitListener;
import levelsandgame.GameLevel;

/**
 * a blockandpaddle.BlockRemover is in charge of removing blocks and Aliens from the game, as well as keeping count
 * of the number of blocks that remain.
 *
 * @ 21.05.18
 * @ author: Idan Twito
 */
public class BlockRemover implements HitListener {
    //members
    private GameLevel game;
    private Counter remainingBlocks;
    private AliensCollection aliensCollection;


    /**
     * the constructor.
     *
     * @param game            the game we want to be able to remove the Blocks from
     * @param remainingBlocks - indicators.Counter object which contains number of the remaining Blocks in this Game.
     */
    public BlockRemover(GameLevel game, Counter remainingBlocks) {
        this.game = game;
        this.remainingBlocks = remainingBlocks;
        this.aliensCollection = null;
    }

    /**
     * Constructor.
     *
     * @param aliensCollection the Aliens Group in the Game.
     */
    public BlockRemover(AliensCollection aliensCollection) {
        this.game = null;
        this.aliensCollection = aliensCollection;
        this.remainingBlocks = null;
    }

    /**
     * @param beingHit the blockandpaddle.Block that was involved in the hit
     * @param hitter   the geometricshapes.Ball that was involved in the hit
     */
    public void hitEvent(Block beingHit, Ball hitter) {
        if (aliensCollection == null) {
            if (beingHit.getHitPoints() == 0) {
                //   this.remainingBlocks.decrease(1);
                if (!beingHit.isShield() && !hitter.playersBullet()) {
                    return;
                }
                beingHit.removeFromGame(this.game);
                beingHit.removeHitListener(this);
                if (remainingBlocks != null && !beingHit.isShield() && hitter.playersBullet()) {
                    remainingBlocks.decrease(1);
                }
            }
        } else {
            if (!beingHit.isShield() && !hitter.playersBullet()) {
                return;
            }
            if (beingHit.getHitPoints() <= 0) {
                aliensCollection.removeFromGame(beingHit);
            }
        }
    }
}
