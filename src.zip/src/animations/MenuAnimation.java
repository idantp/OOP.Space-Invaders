package animations;
/*
 * Idan Twito
 * 311125249
 */

import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import interfaces.Animation;
import interfaces.Menu;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * describes menu interfaces.Animation and implements interfaces.Menu<T>, interfaces.Animation .
 * When the game starts, the user will see a screen stating the game name (space invaders), maybe some graphics,
 * and a list of several options of what to do next. Currently, the options will include:
 * Press "s" to start a new game.
 * Press "h" to see the high scores.
 * Press "q" to quit.
 *
 * @param <T> - describes different return types.
 */
public class MenuAnimation<T> implements Menu<T>, Animation {

    private AnimationRunner ar;
    private List<Menu<T>> subMenuList;
    private List<Boolean> booleanSubMenu;
    //do something according to status: play a game, show high score, or quit.
    private T status;
    //contains all the moving Animations keys, once a key is pressed in its corresponding interfaces.Animation, we skip
    //to another interfaces.Animation.
    private List<String> keysList;
    private String menuTitle;
    //each menu Title
    private List<String> messagesList;
    //what to return once a key of the keyList is pressed
    private List<T> options;
    private KeyboardSensor keyboard;
    //once this gets true the current running interfaces.Animation will stop.
    private boolean stop;

    /**
     * constructor.
     *
     * @param menuTitle KeyboardSensor
     * @param keyboard  String
     * @param ar        animation runner
     */
    public MenuAnimation(AnimationRunner ar, String menuTitle, KeyboardSensor keyboard) {
        this.ar = ar;
        this.subMenuList = new ArrayList<>();
        this.booleanSubMenu = new ArrayList<>();
        this.menuTitle = menuTitle;
        this.keyboard = keyboard;
        this.status = null;
        this.keysList = new ArrayList<>();
        this.messagesList = new ArrayList<>();
        this.options = new ArrayList<>();
        this.stop = false;
    }

    /**
     * adds a new sub interfaces.Menu to the main menu.
     *
     * @param key     - when this key is pressed in the menu the specific sub menu runs
     * @param message - String - describes the next sub menu
     * @param subMenu - creating and displaying the specific sub menu
     */
    public void addSubMenu(String key, String message, Menu<T> subMenu) {
        this.keysList.add(key);
        this.messagesList.add(message);
        this.options.add(null);
        this.subMenuList.add(subMenu);
        this.booleanSubMenu.add(true);
    }

    /**
     * adds a new selection(interfaces.Animation) to the main menu.
     *
     * @param key       - String - when this key is pressed in the menu the specific interfaces.Animation runs
     * @param message   - String - describes the next interfaces.Animation
     * @param returnVal T - creating and running the specific interfaces.Animation
     */
    public void addSelection(String key, String message, T returnVal) {
        keysList.add(key);
        messagesList.add(message);
        options.add(returnVal);
        this.subMenuList.add(null);
        this.booleanSubMenu.add(false);
    }

    /**
     * return the status of this menu.
     *
     * @return T status.
     */
    public T getStatus() {
        T currentStatus = this.status;
        this.stop = false;
        this.status = null;
        return currentStatus;
    }


    /**
     * creates the frame of this interfaces.Animation.
     *
     * @param d  this drawsurface is given from the animations.AnimationRunner
     * @param dt specifies the amount of seconds passed since the last call
     */
    public void doOneFrame(DrawSurface d, double dt) {
        //creates the background
        int keyWidth = d.getWidth() / 4;
        int keyHeight = d.getHeight() / 3;
        d.setColor(new Color(0xBCBC95));
        d.fillRectangle(0, 0, 800, 600);
        d.setColor(new Color(0xE6DA27));
        d.drawText(d.getWidth() / 10, d.getHeight() / 10, this.menuTitle, 50);
        d.setColor(Color.BLACK);
        for (int i = 0; i < keysList.size(); i++) {
            d.drawText(keyWidth, keyHeight, "(" + keysList.get(i) + ") - " + messagesList.get(i), 35);
            keyHeight += 50;
        }
        //if one of the keys in keysList is pressed - move to the corresponding interfaces.Animation.
        for (int i = 0; i < keysList.size(); i++) {
            if (keyboard.isPressed(keysList.get(i)) && (this.booleanSubMenu.get(i))) {
                this.ar.run(this.subMenuList.get(i));
                //stop this(menu) interfaces.Animation.
                this.stop = true;
                //sets the status with the interfaces.Animation we need to show on the screen right now.
                this.status = this.subMenuList.get(i).getStatus();
                break;
            } else if (keyboard.isPressed(keysList.get(i)) && !(this.booleanSubMenu.get(i))) {
                this.stop = true;
                this.status = this.options.get(i);
            }
        }
    }

    /**
     * determines when to stop the interfaces.Animation. Once this function returns true the animation will stop,
     * otherwise it will run.
     *
     * @return Boolean.
     */
    public boolean shouldStop() {
        return this.stop;
    }

    /**
     * makes sure once another animation is called and runs from menu, that the menu interfaces.Animation will not over.
     */
    public void stopAnimation() {
        this.status = null;
        this.stop = false;
    }
}
