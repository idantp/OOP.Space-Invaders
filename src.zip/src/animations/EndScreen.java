package animations;
/*
 * Idan Twito
 * 311125249
 */

import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import interfaces.Animation;

import java.awt.Color;

/**
 * this Class implements interfaces.Animation, and does the following:
 * If the game ended with the player losing all his lives, the end screen displays the message:
 * "Game Over. Your score is X" (X indicates the final score).
 * If the game ended by clearing all the levelsandgame, the screen should display "You Win! Your score is X".
 *
 * @ 21.05.18
 * @ author: Idan Twito
 */
public class EndScreen implements Animation {
    private boolean isGameOver;
    private KeyboardSensor keyboard;
    private boolean stop;
    private int score;

    /**
     * Constructor.
     *
     * @param isGameOver boolean - if the Game is Over - gets true, otherwise (the player wins) - false.
     * @param keyboard   KeyboardSensor
     * @param score      int - the current score of the player.
     */
    public EndScreen(boolean isGameOver, KeyboardSensor keyboard, int score) {
        this.isGameOver = isGameOver;
        this.keyboard = keyboard;
        //indicates when this interfaces.Animation should stop
        this.stop = false;
        this.score = score;
    }

    /**
     * in charge of the logic of each animation.
     *
     * @param d  this drawsurface is given from the animations.AnimationRunner
     * @param dt specifies the amount of seconds passed since the last call
     */
    public void doOneFrame(DrawSurface d, double dt) {
        //background
        d.setColor(Color.BLACK);
        d.fillRectangle(0, 0, 800, 600);
        d.setColor(Color.WHITE);
        //if the player lost and the Game is Over print an appropriate message.
        if (isGameOver) {
            d.drawText((d.getWidth() / 4) - 10, d.getHeight() / 2, "Game Over. Your score is: " + this.score, 32);
        } else {
            //else - if the player won the Game print an appropriate message.
            d.drawText((d.getWidth() / 5) + 25, d.getHeight() / 2, "You Win! Your score is: " + this.score, 32);
        }
        d.drawText((d.getWidth() / 5) + 60, 400, "Press 'SPACE' to proceed", 32);
    }

    /**
     * determines when to stop the interfaces.Animation. Once this function returns true the animation will stop,
     * otherwise it will run.
     *
     * @return Boolean.
     */
    public boolean shouldStop() {
        return this.stop;
    }
}
