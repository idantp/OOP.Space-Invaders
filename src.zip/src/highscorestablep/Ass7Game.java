package highscorestablep;
/*
 * Idan Twito
 * 311125249
 */

import animations.AnimationRunner;
import animations.MenuAnimation;
import biuoop.GUI;
import biuoop.KeyboardSensor;
import interfaces.LevelInformation;
import interfaces.Menu;
import interfaces.Task;
import levelsandgame.StartGame;
import tasks.CloseGameTask;
import tasks.ShowHiScoresTask;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * This Class creates a game object, initializes and runs it. it Runs Space Invaders Game in the following way:
 * When the lowest alien in the formation reaches the height of the shields (or where the shields were,
 * if all shields are destroyed), the player looses a life.
 * When the player looses a life, the aliens reset their position back to the top, returning to their
 * original speed (shields remain unchanged).
 * When the bullets hit the shields, it puts a small hole in them. When the bullet hits an alien, the alien dies.
 * When all the aliens die, the player wins.
 *
 * @ 20.04.18
 * @ Last Updated 21.05.18
 * @ author: Idan Twito
 */

public class Ass7Game {


    /**
     * the main method of highscorestablep.Ass7Game. it implements what written above.
     *
     * @param args gets no parameters.
     */
    public static void main(String[] args) {
        int levelNumber;
        GUI gui = new GUI("Space Invaders", 800, 600);
        AnimationRunner ar = new AnimationRunner(gui, 60);
        KeyboardSensor ks = gui.getKeyboardSensor();
        HighScoresTable scoresTable = new HighScoresTable(5);
        try {
            scoresTable.load(new File("highscores.txt"));
        } catch (Exception e) {
            System.out.println("Something went wrong while loading from highscores.txt.");
        }
        //loads the levels
        while (true) {
            List<LevelInformation> levels = new ArrayList<>();
            for (int i = 0; i < 75; i++) {
                levelNumber = i + 1;
                LevelInformation level = new StartGame(75, 450, levelNumber);
                levelNumber++;
                levels.add(level);
            }
            //Menu<Task<Void>> levelSetsMenu = new MenuAnimation<>(ar, "Game-Level", ks);
            //levelSetRead(ar, levelSetsMenu, txtFile, ks, scoresTable);
            Menu<Task<Void>> menu = new MenuAnimation<Task<Void>>(ar, "Space-Invaders", ks);
            menu.addSelection("s", "Start Game", new tasks.ShowGameTask(new GameFlow(ar, ks, scoresTable),
                    levels));
            menu.addSelection("h", "High Scores Table", new ShowHiScoresTask(ar,
                    new HighScoresAnimation(scoresTable), ks));
            menu.addSelection("q", "Close Game", new CloseGameTask());
            //runs menu interfaces.Animation
            ar.run(menu);
            // wait for user selection and gets the status from the menu. once one of the keys in keyList(see in
            //menu Object for more info), task gets the corresponding task,
            // which runs the corresponding interfaces.Animation.
            Task<Void> task = menu.getStatus();
            task.run();
            //tells the menu interfaces.Animation that its interfaces.Animation is not over.
            ((MenuAnimation<Task<Void>>) menu).stopAnimation();
        }
    }
}