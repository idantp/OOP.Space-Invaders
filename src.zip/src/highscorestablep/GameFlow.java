package highscorestablep;
/*
 * Idan Twito
 * 311125249
 */

import animations.AnimationRunner;
import animations.EndScreen;
import animations.KeyPressStoppableAnimation;
import biuoop.DialogManager;
import biuoop.KeyboardSensor;
import indicators.Counter;
import interfaces.LevelInformation;
import levelsandgame.GameLevel;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * This Class is responsible for moving from one level to the next and creating the different levelsandgame.
 *
 * @ 21.05.18
 * @ author: Idan Twito
 */
public class GameFlow {
    //members
    private AnimationRunner ar;
    private KeyboardSensor ks;
    //the remaining lives of the player.
    private Counter numOfLives;
    //the score we want to save from each level to the next one.
    private Counter score;
    private HighScoresTable scoresTable;

    /**
     * Constructor.
     *
     * @param ar          animations.AnimationRunner takes an interfaces.Animation object and runs it
     * @param ks          KeyboardSensor
     * @param scoresTable the high scores Table.
     */
    public GameFlow(AnimationRunner ar, KeyboardSensor ks, HighScoresTable scoresTable) {
        this.ar = ar;
        this.ks = ks;
        this.numOfLives = new Counter(3);
        this.score = new Counter(0);
        this.scoresTable = scoresTable;
    }


    /**
     * this method creates each Level. Once the Player is out of lives - Game is Over. Once the Player has
     * "killed" all the Blocks of the game - the method skips to the next Level while keeping the current
     * lives and score of the Player.
     *
     * @param levels List<interfaces.LevelInformation> - contains all the the levelsandgame of the Game.
     */
    public void runLevels(List<LevelInformation> levels) {
        //runs all over the 4 levelsandgame
        for (LevelInformation levelInfo : levels) {
            //creates and initialize the given levelsandgame.GameLevel.
            GameLevel level = new GameLevel(this.ar, levelInfo, score, numOfLives);

            level.initialize();
            //running this levelsandgame.GameLevel as long as the player's lives and the remaining blocks are not 0.
            while (level.getLives() > 0 && level.getRemainedBlocks() > 0) {
                level.playOneTurn();
            }
            //if the player's lives = 0, Game Over.
            if (numOfLives.getValue() == 0) {
                //if the player's score entitles him to be listed on the high-scores table
                if (this.scoresTable.getRank(this.score.getValue()) > 0) {
                    DialogManager dialog = this.ar.getGui().getDialogManager();
                    String name = dialog.showQuestionDialog("Name", "What is your name?", "");
                    //add this player and his score in the right rank.
                    this.scoresTable.add(new ScoreInfo(name, this.score.getValue()));
                    //save the table after the adding.
                    try {
                        this.scoresTable.save(new File("highscores.txt"));
                    } catch (IOException e) {
                        System.out.println("Something went wrong while writing to ''highscores.txt'`' File.");
                    }
                }
                //creating EndsScreen interfaces.Animation
                EndScreen loseEndScreen = new EndScreen(true, ks, this.score.getValue());
                //creating animations.KeyPressStoppableAnimation of EndsScreen with SPACE KEY stopping key.
                KeyPressStoppableAnimation loseEndScreenKey =
                        new KeyPressStoppableAnimation(ks, ks.SPACE_KEY, loseEndScreen);
                //running loseEndScreenKey.
                this.ar.run(loseEndScreenKey);
                //once SPACE KEY is pressed we create highscorestablep.HighScoresAnimation interfaces.Animation.
                HighScoresAnimation highScoresAnimation = new HighScoresAnimation(scoresTable);
                //creating animations.KeyPressStoppableAnimation of highscorestablep.
                // HighScoresAnimation with SPACE KEY stopping key.
                KeyPressStoppableAnimation scoresAnimationKey =
                        new KeyPressStoppableAnimation(ks, "space", highScoresAnimation);
                //running scoresAnimationKey.
                this.ar.run(scoresAnimationKey);
                return;
            }
        }
        //if the player's score entitles him to be listed on the high-scores table
        if (this.scoresTable.getRank(this.score.getValue()) > 0) {
            DialogManager dialog = this.ar.getGui().getDialogManager();
            String name = dialog.showQuestionDialog("Name", "What is your name?", "");
            //add this player and his score in the right rank.
            this.scoresTable.add(new ScoreInfo(name, this.score.getValue()));
            //save the table after the adding.
            try {
                this.scoresTable.save(new File("highscores.txt"));
            } catch (IOException e) {
                System.out.println("Something went wrong while writing to ''highscores.txt'`' File.");
            }
        }
        //if the player wins the game: do the same as the player loses but with a winning animations.EndScreen
        EndScreen winEndScreen = new EndScreen(false, ks, this.score.getValue());
        KeyPressStoppableAnimation winEndScreenKey = new KeyPressStoppableAnimation(ks, ks.SPACE_KEY, winEndScreen);
        this.ar.run(winEndScreenKey);
        HighScoresAnimation highScoresAnimation = new HighScoresAnimation(scoresTable);
        KeyPressStoppableAnimation scoresAnimationKey =
                new KeyPressStoppableAnimation(ks, "space", highScoresAnimation);
        this.ar.run(scoresAnimationKey);
        return;
    }
}