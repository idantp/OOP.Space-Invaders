package interfaces;
/*
 * Idan Twito
 * 311125249
 */

import geometricshapes.Ball;

/**
 * in charge of creating both: Aliens' and player's bullets (Ball).
 */
public interface BallCreator {

    /**
     * Constructor extends Ball.
     *
     * @param xCoordinate the x Coordinate of the Ball's Center Points.
     * @param yCoordinate the y Coordinate of the Ball's Center Points.
     * @return returns a new Ball.
     */
    Ball bullet(int xCoordinate, int yCoordinate);
}
