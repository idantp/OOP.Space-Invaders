package interfaces;
/*
 * Idan Twito
 * 311125249
 */

import biuoop.DrawSurface;

/**
 * this class describes different animations that we will run while playing the game.
 */
public interface Animation {
    /**
     * in charge of the logic of each animation.
     *
     * @param d  this drawsurface is given from the animations.AnimationRunner
     * @param dt specifies the amount of seconds passed since the last call
     */
    void doOneFrame(DrawSurface d, double dt);

    /**
     * determines when to stop the interfaces.Animation. Once this function returns true the animation will stop,
     * otherwise it will run.
     *
     * @return Boolean.
     */
    boolean shouldStop();

}
