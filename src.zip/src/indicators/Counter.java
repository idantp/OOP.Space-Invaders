package indicators;
/*
 * Idan Twito
 * 311125249
 */

/**
 * a Class that counts things.
 *
 * @ 21.05.18
 * @ author: Idan Twito
 */
public class Counter {
    //member
    private int count;

    /**
     * constructor.
     *
     * @param count - the counter
     */
    public Counter(int count) {
        this.count = count;
    }

    /**
     * add number to current count.
     *
     * @param number the number we want to add
     */
    public void increase(int number) {
        this.count += number;
    }

    /**
     * subtract number from current count.
     *
     * @param number the number we want to substract
     */
    public void decrease(int number) {
        this.count -= number;
    }

    /**
     * get current count.
     *
     * @return this.count
     */
    public int getValue() {
        return this.count;
    }
}
