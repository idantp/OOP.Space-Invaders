package indicators;
/*
 * Idan Twito
 * 311125249
 */

import biuoop.DrawSurface;
import interfaces.Sprite;
import levelsandgame.GameLevel;

import java.awt.Color;

/**
 * indicates the player's lives and prints them on the top of the screen.
 *
 * @ 21.05.18
 * @ author: Idan Twito
 */
public class LivesIndicator implements Sprite {
    //where to Print
    public static final int TEXT_HEIGHT = 20;
    public static final int TEXT_WIDTH = 100;
    private Counter livesCounter;

    /**
     * Constructor.
     *
     * @param livesCounter counts the player's lives
     */
    public LivesIndicator(Counter livesCounter) {
        this.livesCounter = livesCounter;
    }

    /**
     * the function draws the string on the screen (using DrawSurface d).
     *
     * @param d - the DrawSurface of the GUI that was created.
     */
    public void drawOn(DrawSurface d) {
        d.setColor(Color.BLACK);
        d.drawText(TEXT_WIDTH, TEXT_HEIGHT, "Lives: " + Integer.toString(this.livesCounter.getValue()), 20);
    }

    /**
     * notify the sprite that time has passed.
     * @param dt specifies the amount of seconds passed since the last call
     */
    public void timePassed(double dt) {

    }

    /**
     * this function adds this indicators.LivesIndicator to the given GemeLevel.
     *
     * @param g - the GemeLevel that we want to add this indicators.LivesIndicator to.
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
    }

}
