package levelsandgame;
/*
 * Idan Twito
 * 311125249
 */

import spaceinvaders.AliensCollection;
import biuoop.DrawSurface;
import blockandpaddle.Block;
import geometricshapes.Rectangle;
import interfaces.LevelInformation;
import interfaces.Sprite;

import geometricshapes.Point;

import java.awt.Color;
import java.util.List;
import java.util.ArrayList;

/**
 * describes how the level (levels) in this Game (space invaders) will look like. it implements LevelInformation
 */
public class StartGame implements LevelInformation {
    private AliensCollection aliensCollection;
    private int level;
    private int paddleSpeed;
    private int paddleWidth;

    /**
     * constructor.
     *
     * @param paddleWidth int
     * @param paddleSpeed int
     * @param level       int - the level's number - each level the aliens move faster.
     */
    public StartGame(int paddleWidth, int paddleSpeed, int level) {
        this.paddleSpeed = paddleSpeed;
        this.level = level;
        this.paddleWidth = paddleWidth;
        this.aliensCollection = new AliensCollection(60 * Math.pow(1.7, level - 1));
    }

    /**
     * creates a List which contains all the Blocks in the Game. Here we create the shields of the Game,
     * in addition add to that list the Aliens because they extend Block.
     *
     * @return shieldsBlocks List.
     */
    public List<Block> blocks() {
        Color shieldColor = Color.YELLOW;
        int shieldYCoordinate = 500;
        int shieldXCoordinate;
        List<Block> shieldsList = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            if (i == 0) {
                shieldXCoordinate = 60;
            } else if (i == 1) {
                shieldXCoordinate = 310;
            } else {
                shieldXCoordinate = 560;
            }
            for (int j = 0; j < 3; j++) {
                int nextYCoordinate = shieldYCoordinate + j * 5;
                for (int m = 0; m < 35; m++) {
                    Point p = new Point(shieldXCoordinate + m * 5, nextYCoordinate);
                    Rectangle rectangle = new Rectangle(p, 6, 6);
                    Block shield = new Block(rectangle, shieldColor, true);
                    shieldsList.add(shield);
                }
            }
        }
        shieldsList.addAll(aliensCollection.getAliens());
        return shieldsList;
    }

    /**
     * @return - returns the paddle's speed.
     */
    public int paddleSpeed() {
        return this.paddleSpeed;
    }

    /**
     * @return - returns the initial level alien formation.
     */
    public AliensCollection getAliensCollection() {
        return aliensCollection;
    }

    /**
     * @return - returns the paddle's width.
     */
    public int paddleWidth() {
        return this.paddleWidth;
    }

    /**
     * @return - returns the level's name.
     */
    public String levelName() {
        return ("Spacecraft Invaders - Level: " + level);
    }

    /**
     * @return - returns the background of the game.
     */
    public Sprite getBackground() {
        return new Sprite() {
            @Override
            public void drawOn(DrawSurface d) {
                d.setColor(Color.BLACK);
                d.fillRectangle(0, 0, d.getWidth(), d.getHeight());
            }

            @Override
            public void timePassed(double dt) {

            }

            @Override
            public void addToGame(GameLevel g) {

            }
        };
    }


    /**
     * @return - returns the number of blocks that can be removed from the game.
     */
    public int numberOfBlocksToRemove() {
        return 50;
    }

    /**
     * @return - returns the list of blocks in the level.
     */

}
