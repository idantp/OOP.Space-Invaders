package levelsandgame;
/*
 * Idan Twito
 * 311125249
 */

import geometricshapes.CollisionInfo;
import geometricshapes.Line;
import geometricshapes.Point;
import interfaces.Collidable;

import java.util.ArrayList;
import java.util.List;

/**
 * levelsandgame.GameEnvironment contains an ArrayLIst which contains all the collidables Object in the game.
 *
 * @ 20.04.18
 * @ last update: 21.05.18
 * @ author: Idan Twito
 */
public class GameEnvironment {
    private List<Collidable> collidableObjectsList;

    /**
     * constructor of this object.
     */
    public GameEnvironment() {
        this.collidableObjectsList = new ArrayList<Collidable>();
    }

    /**
     * the function gets a new collidable and adds it the the levelsandgame.GameEnvironment's collidables list.
     *
     * @param c - new collidable in the game environment
     */
    public void addCollidable(Collidable c) {
        this.collidableObjectsList.add(c);
    }

    /**
     * this function checks whether the object collides any of the collidables or not.
     * if there is a collision - the function return the information of about the closest collision point.
     * if no collision found - return null.
     *
     * @param trajectory - the moving course of the given object.
     * @return geometricshapes.CollisionInfo closestPointCollisionInfo or null.
     */
    public CollisionInfo getClosestCollision(Line trajectory) {
        //will contain the distance of trajectory start with the closest collidable's interesction point
        double distance = 0;
        //contains a temp distance when we find a new closest collision point
        double tempDistance;
        //will contain the information of the closest collision
        Point finalClosestPoint = null;
        //contains a temp Closest geometricshapes.Point when we find a new closest collision point
        Point tempClosestPoint;
        //will contain the collision information of the closest collision
        CollisionInfo closestPointCollisionInfo;
        //differs between the first closest collision point and the others
        int numOfClosestPoints = 0;
        //contains the final interfaces.Collidable that is the closest to strart point of trajectory.
        Collidable finalCollidable = null;
        //runs over collidableObjectsList
        for (Collidable collidable : collidableObjectsList) {
            //if a closest intersection point with the line was found:
            if (trajectory.closestIntersectionToStartOfLine(collidable.getCollisionRectangle()) != null) {
                //stores the current distance between the start of the line and the point that was found
                tempDistance = trajectory.start().distance(trajectory.closestIntersectionToStartOfLine(
                        collidable.getCollisionRectangle()));
                //stores the point that was found
                tempClosestPoint = trajectory.closestIntersectionToStartOfLine(collidable.getCollisionRectangle());
                //first point was found
                if (numOfClosestPoints == 0) {
                    //gets the first distance
                    distance = tempDistance;
                    //gets the first point that was found
                    finalClosestPoint = tempClosestPoint;
                    finalCollidable = collidable;
                    numOfClosestPoints++;
                } else {
                    //if the current distance is smallest that was found so far:
                    if (tempDistance < distance) {
                        //store this distance
                        distance = tempDistance;
                        //store the point that was found because it's the closest one so far.
                        finalClosestPoint = tempClosestPoint;
                        finalCollidable = collidable;
                    }
                }
            }
        }
        // if no collision was found - return null.
        if (numOfClosestPoints == 0) {
            return null;
        } else {
            closestPointCollisionInfo = new CollisionInfo(finalClosestPoint, finalCollidable);
            //returning the closest collision point information
            return closestPointCollisionInfo;
        }
    }

    /**
     * return a list consists of all the collidables in the game.
     * @return this.collidableObjectsList
     */
    public List<Collidable> getCollidableObjectsList() {
        return this.collidableObjectsList;
    }
}