package levelsandgame;
/*
 * Idan Twito
 * 311125249
 */

import biuoop.DrawSurface;
import interfaces.Sprite;

import java.util.ArrayList;
import java.util.List;

/**
 * levelsandgame.SpriteCollection contains an ArrayLIst of all the Sprites Object in the game.
 *
 * @ 20.04.18
 * @ author: Idan Twito
 */
public class SpriteCollection {
    private List<Sprite> allSprites;

    /**
     * the constructor of this object. initializing an ArrayList of sprites.
     */
    public SpriteCollection() {
        this.allSprites = new ArrayList<Sprite>();
    }

    /**
     * adds the given sprite to the list.
     *
     * @param s - the given sprite we want to add to the sprites list
     */
    public void addSprite(Sprite s) {
        allSprites.add(s);
    }

    /**
     * call timePassed() on all sprites.
     *
     * @param dt specifies the amount of seconds passed since the last call
     */
    public void notifyAllTimePassed(double dt) {
        List<Sprite> spriteList = new ArrayList<Sprite>(this.allSprites);
        for (Sprite spriteObject : spriteList) {
            spriteObject.timePassed(dt);
        }
    }

    /**
     * call drawOn(d) on all sprites. drawing all the sprites on the given surface.
     *
     * @param d - the given surface we can draw on.
     */
    public void drawAllOn(DrawSurface d) {
        for (Sprite spriteObject : allSprites) {
            spriteObject.drawOn(d);
        }
    }

    /**
     * return a list consists of all the sprites in the game.
     *
     * @return this.allSprites
     */
    public List<Sprite> getSpriteObjectsList() {
        return this.allSprites;
    }
}