package levelsandgame;
/*
 * Idan Twito
 * 311125249
 */

import animations.AnimationRunner;
import animations.CountdownAnimation;
import animations.KeyPressStoppableAnimation;
import animations.PauseScreen;
import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import blockandpaddle.Block;
import blockandpaddle.BlockRemover;
import blockandpaddle.SpaceRemover;
import blockandpaddle.PlayerBullet;
import geometricshapes.Rectangle;
import geometricshapes.Point;
import geometricshapes.Ball;
import geometricshapes.BallRemover;

import indicators.LevelNameIndicator;
import indicators.LivesIndicator;
import indicators.ScoreIndicator;
import indicators.Counter;
import indicators.ScoreTrackingListener;
import interfaces.LevelInformation;
import interfaces.BallCreator;
import interfaces.Collidable;
import interfaces.Sprite;
import interfaces.Animation;
import spaceinvaders.Spacecraft;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * levelsandgame.GameLevel contains an ArrayList allSprites that contains all the Sprites of the game,
 * levelsandgame.GameEnvironment Object(contains all the collidables) and the GUI of the game.
 *
 * @ 21.05.18
 * @ author: Idan Twito
 */
public class GameLevel implements Animation {
    //contains all the Sprites of this levelsandgame.GameLevel.
    private SpriteCollection allSprites;
    private List<Ball> bullets;
    //contains all the Collidables of this levelsandgame.GameLevel.
    private GameEnvironment environment;
    //this object contains how much Blocks remained in the game.
    private Counter remainedBlock;
    private Counter playerWasHit;
    //this object contains the Score of the Player.
    private Counter score;
    ////this object contains how much lives left to the player.
    private Counter livesCounter;
    //Runs the Animations
    private AnimationRunner runner;
    private boolean running;
    private KeyboardSensor keyboard;
    private LevelInformation levelInfo;

    /**
     * Constructor.
     *
     * @param runner       Animations Runner
     * @param levelInfo    level information.
     * @param score        score indicator of the player.
     * @param livesCounter lives indicator of the player.
     */
    public GameLevel(AnimationRunner runner, LevelInformation levelInfo, Counter score, Counter livesCounter) {
        this.allSprites = new SpriteCollection();
        this.environment = new GameEnvironment();
        this.remainedBlock = new Counter(0);
        this.score = score;
        this.livesCounter = livesCounter;
        this.running = true;
        this.runner = runner;
        this.keyboard = this.runner.getGui().getKeyboardSensor();
        this.levelInfo = levelInfo;
        this.bullets = new ArrayList<>();
    }

    /**
     * the function gets a new collidable and adds it the the levelsandgame.GameEnvironment's collidables list.
     *
     * @param c - new collidable in the game environment
     */
    public void addCollidable(Collidable c) {
        this.environment.addCollidable(c);
    }

    /**
     * adds the given sprite to the list.
     *
     * @param s - the given sprite we want to add to the sprites list
     */
    public void addSprite(Sprite s) {
        this.allSprites.addSprite(s);
    }

    /**
     * returns this Game level's GameEnvironment.
     *
     * @return this.environment
     */
    public GameEnvironment getEnvironment() {
        return environment;
    }

    // Initialize a new game: create the Blocks and geometricshapes.Ball (and spaceinvaders.Spacecraft)
    // and add them to the game.

    /**
     * this function initializes a new game: it creates the Blocks and geometricshapes.
     * Ball (and spaceinvaders.Spacecraft) and add them to the game.
     */
    public void initialize() {
        createBoundaries();
        ScoreIndicator scoreIndicator = new ScoreIndicator(score);
        scoreIndicator.addToGame(this);
        LivesIndicator livesIndicator = new LivesIndicator(livesCounter);
        livesIndicator.addToGame(this);
        LevelNameIndicator levelNameIndicator = new LevelNameIndicator(levelInfo);
        levelNameIndicator.addToGame(this);
        levelInfo.getBackground().addToGame(this);
        ScoreTrackingListener scoreTrackingListener = new ScoreTrackingListener(this.score);
        List<Block> gameBlocks = this.levelInfo.blocks();
        BlockRemover blockRemover = new BlockRemover(this, this.remainedBlock);
        //adding the blocks to the game as collidables and sprites whilst adding their hit listeners.
        for (int i = 0; i < gameBlocks.size(); i++) {
            gameBlocks.get(i).addToGame(this);
            gameBlocks.get(i).addHitListener(blockRemover);
            gameBlocks.get(i).addHitListener(new BallRemover(this));
            //blockList.get(i).addHitListener(scoreTrackingListener);
            //     this.blockCounter.increase(1);
        }
        this.remainedBlock.increase(50);
        levelInfo.getAliensCollection().addHitListener(
                new BlockRemover(levelInfo.getAliensCollection()));
        levelInfo.getAliensCollection().addHitListener(new BallRemover(this));
        levelInfo.getAliensCollection().addHitListener(scoreTrackingListener);
        levelInfo.getAliensCollection().addToGame(this);
    }

    /**
     * creates the same Boundaries Blocks in each Level.
     */
    public void createBoundaries() {
        //Here we create all the 4 edge blocks of the game
        Point p15 = new Point(0, 1);
        Rectangle topRect = new Rectangle(p15, 800, 1);
        Block topBlock = new Block(topRect, Color.GRAY, 0);
        Point p10 = new Point(0, 650);
        Rectangle bottomRect = new Rectangle(p10, 800, 20);
        Block bottomBlock = new Block(bottomRect, Color.GRAY, 0);
        BallRemover ballRemover = new BallRemover(this);
        //register the geometricshapes.BallRemover class as a listener of the death-region.
        bottomBlock.addHitListener(ballRemover);
        topBlock.addHitListener(ballRemover);
        Point p11 = new Point(776, 25);
        //Rectangle rightRect = new Rectangle(p11, 25, 600);
        //Block rightBlock = new Block(rightRect, Color.GRAY, 0);
        //adding all these 4 blocks to the game
        topBlock.addToGame(this);
        bottomBlock.addToGame(this);
    }

    /**
     * this function starts the game.
     */
    public void run() {
        while (this.livesCounter.getValue() > 0) {
            playOneTurn();
        }
    }


    /**
     * this function starts the animation loop of every turn. It creates the game's:
     * spaceinvaders.Spacecraft and Balls
     * Tells when the player lost this Turn, and when the game is over
     * counts the lives and the score of the player using assisting methods
     */
    public void playOneTurn() {
        //creating the Balls
        //creating the spaceinvaders.Spacecraft of the game in the center of the screen
        Point rectangleUpperLeft = new Point((800 - levelInfo.paddleWidth()) / 2, 560);
        Rectangle paddleRect = new Rectangle(rectangleUpperLeft, levelInfo.paddleWidth(), 20);
        Spacecraft gameSpacecraft = new Spacecraft(keyboard, Color.orange, paddleRect, levelInfo.paddleSpeed(),
                20, 780);
        GameLevel temp = this;
        gameSpacecraft.setBallCreator(new BallCreator() {
            @Override
            public Ball bullet(int x, int y) {
                Ball toShoot = new PlayerBullet(x, y);
                toShoot.setGameEnvironment(environment);
                toShoot.addToGame(temp);
                temp.addBullet(toShoot);
                toShoot.setPlayerBullet(true);
                return toShoot;
            }
        });
        this.playerWasHit = new Counter(0);
        gameSpacecraft.addPaddleRemover(new SpaceRemover(playerWasHit));
        gameSpacecraft.addToGame(this);
        //countdown before turn starts.
        this.runner.run(new CountdownAnimation(2, 3, allSprites, levelInfo));
        this.running = true;
        // use our runner to run the current animation -- which is one turn of the game.
        this.runner.run(this);
        //removes the spaceinvaders.Spacecraft of this Game once the player lost a round or the whole Game.
        gameSpacecraft.removeFromGame(this);

    }

    /**
     * removes the given collidable from the list that contains all the collidables in the game.
     *
     * @param c the collidable we want to remove from the list
     */
    public void removeCollidable(Collidable c) {
        this.environment.getCollidableObjectsList().remove(c);
    }

    /**
     * removes the given sprite from the list that contains all the sprites in the game.
     *
     * @param s the sprite we want to remove from the list
     */
    public void removeSprite(Sprite s) {
        this.allSprites.getSpriteObjectsList().remove(s);
    }

    /**
     * returns the current score of the player.
     *
     * @return indicators.Counter this.score
     */
    public Counter getScore() {
        return this.score;
    }

    /**
     * @param surface this drawsurface is given from the animations.AnimationRunner
     * @param dt      specifies the amount of seconds passed since the last call
     */
    public void doOneFrame(DrawSurface surface, double dt) {
        this.levelInfo.getBackground().drawOn(surface);
        //creating animations.PauseScreen
        PauseScreen pauseScreen = new PauseScreen(keyboard);
        KeyPressStoppableAnimation pauseScreenK = new KeyPressStoppableAnimation(keyboard, "space", pauseScreen);
        //draw all sprites
        this.allSprites.drawAllOn(surface);
        //notify all sprites the time has passed
        this.allSprites.notifyAllTimePassed(dt);
        if (this.remainedBlock.getValue() == 0) {
            this.running = false;
        }
        //pausing the game until we press "p" button.
        if (this.keyboard.isPressed("p")) {
            this.runner.run(pauseScreenK);
        }
        boolean oneTurnlose = this.levelInfo.getAliensCollection().turnStatus();
        if (playerWasHit.getValue() < 0 || !oneTurnlose) {
            this.running = false;
            levelInfo.getAliensCollection().rePosition();
            for (int i = 0; i < bullets.size(); i++) {
                bullets.get(i).removeFromGame(this);
            }
            this.livesCounter.decrease(1);
        }
    }

    /**
     * add a new bullet to this GameLevel.
     *
     * @param bullet Ball.
     */
    public void addBullet(Ball bullet) {
        bullets.add(bullet);
    }

    /**
     * when gets false this game stops.
     *
     * @return true or false
     */
    public boolean shouldStop() {
        return !this.running;
    }

    /**
     * returns the player's lives number.
     *
     * @return this.livesCounter.getValue() Integer
     */
    public int getLives() {
        return this.livesCounter.getValue();
    }

    /**
     * return how many aliens left to kill in this level.
     *
     * @return this.remainedBlock.getValue() Integer
     */
    public int getRemainedBlocks() {
        return this.remainedBlock.getValue();
    }

}
