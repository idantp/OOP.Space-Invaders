package spaceinvaders;
/*
 * Idan Twito
 * 311125249
 */

import biuoop.DrawSurface;
import blockandpaddle.Block;
import geometricshapes.Ball;
import geometricshapes.Point;
import geometricshapes.Rectangle;
import geometricshapes.Velocity;
import interfaces.HitListener;
import interfaces.HitNotifier;
import levelsandgame.GameLevel;

import java.util.List;

import javax.imageio.ImageIO;
import java.awt.Image;
import java.util.ArrayList;

/**
 * this class describes an Alien in each level. it extends a Block and has 1 hitPoint. it can move left,right
 * down and shoots the player.
 */
public class Alien extends Block implements HitNotifier {
    private List<HitListener> hitListeners;
    private int xCoordinate;
    private int yCoordinate;
    private static Image image;
    private int hitPoints = 1;

    /**
     * Constructor.
     *
     * @param xCoordinate the the x coordinate of the upperLeft Point of the alien's rectangle.
     * @param yCoordinate the the y coordinate of the upperLeft Point of the alien's rectangle.
     */
    public Alien(int xCoordinate, int yCoordinate) {
        this.hitListeners = new ArrayList<HitListener>();
        this.xCoordinate = xCoordinate;
        this.yCoordinate = yCoordinate;
        if (image == null) {
            try {
                this.image = ImageIO.read(ClassLoader.getSystemClassLoader().getResourceAsStream("enemy.png"));
            } catch (Exception e) {
                System.out.println("Something went wrong while uploading enemy image");
                System.exit(-1);
            }
        }
    }

    /**
     * moves this alien left,right or down when necessary.
     *
     * @param x moves it right and left
     * @param y moves it down.
     */
    public void moveOneStep(int x, int y) {
        this.xCoordinate += x;
        this.yCoordinate += y;
    }

    /**
     * draws this Alien.
     *
     * @param d draws it on d DrawSurface.
     */
    public void drawOn(DrawSurface d) {
        d.drawImage(xCoordinate, yCoordinate, image);
    }

    /**
     * notifies this Alien that he was hit.
     *
     * @param ball was hit by that ball.
     */
    public void notifyAlienHit(Ball ball) {
        List<HitListener> listeners;
        listeners = this.hitListeners;
        for (int i = 0; i < listeners.size(); i++) {
            listeners.get(i).hitEvent(this, ball);
        }
    }

    /**
     * @param dt specifies the amount of seconds passed since the last call
     */
    @Override
    public void timePassed(double dt) {

    }

    /**
     * @param g - the game that we want to add this block to.
     */
    @Override
    public void addToGame(GameLevel g) {
        g.addSprite(this);
        g.addCollidable(this);

    }

    /**
     * the function returns the object of the colliding object.
     *
     * @return rectangle
     */
    @Override
    public Rectangle getCollisionRectangle() {
        Point point = new Point(xCoordinate, yCoordinate);
        Rectangle rectangle = new Rectangle(point, 40, 30);
        return rectangle;
    }

    /**
     * if the player's bullet hits the Alien - remove it from game.
     *
     * @param hitter          - the geometricshapes.Ball that is involved in the this hit.
     * @param collisionPoint  geometricshapes.Point that describes the collision point.
     * @param currentVelocity geometricshapes.Velocity - the current velocity of the colliding object.
     * @return currentVelocity Velocity.
     */
    @Override
    public Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity) {

        if (hitter.getVelocity().getDy() < 0) {
            this.hitPoints--;
            notifyAlienHit(hitter);
        }
        return currentVelocity;
    }

    /**
     * removes this Alien from Sprites and Collidables Lists, removes it from the Level.
     *
     * @param gameLevel gameLevel that is being playes.
     */
    public void removeFromGame(GameLevel gameLevel) {
        gameLevel.removeSprite(this);
        gameLevel.removeCollidable(this);
    }

    /**
     * @param hl an Object that is notified of hit events.
     */
    @Override
    public void addHitListener(HitListener hl) {
        this.hitListeners.add(hl);
    }

    /**
     * returns this Alien's hitPoint number.
     *
     * @return this.hitPoints
     */
    public int getHitPoints() {
        return this.hitPoints;
    }

    /**
     * @param hl an Object that is notified of hit events
     */
    @Override
    public void removeHitListener(HitListener hl) {
        this.hitListeners.remove(hl);
    }


}
