package spaceinvaders;
/*
 * Idan Twito
 * 311125249
 */

import biuoop.DrawSurface;
import blockandpaddle.Block;
import blockandpaddle.BlockRemover;
import geometricshapes.Ball;
import geometricshapes.Point;
import interfaces.BallCreator;
import interfaces.HitListener;
import interfaces.Sprite;
import levelsandgame.GameLevel;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * this Class describes the Aliens group in each level. first it contains 50 Aliens and each one of them is removed
 * once being hit. they move together. only one of them can shoot at a time and it must be the lowest one.
 */
public class AliensCollection implements Sprite {
    private List<List<spaceinvaders.Alien>> aliensGroup;
    private double startSpeed;
    private double bottomYCoordinate;
    private double speed;
    private BallCreator ballCreator;
    private long lastShoot;

    /**
     * Constructor. the aliens gets new speed every time they go down and every new level.
     *
     * @param speed double.
     */
    public AliensCollection(double speed) {
        BlockRemover blockRemover = new BlockRemover(this);
        this.aliensGroup = new ArrayList<>();
        this.aliensGroup = createAliens(blockRemover);
        this.speed = speed;
        this.lastShoot = 0;
        this.startSpeed = speed;
        this.ballCreator = null;

    }

    /**
     * initializing and creating 50 removable Aliens.
     *
     * @param remover BlockRemover
     * @return 50 aliens
     */
    private List<List<spaceinvaders.Alien>> createAliens(BlockRemover remover) {
        List<List<Alien>> tempList = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            List<Alien> columnAliens = new ArrayList<>();
            for (int j = 4; j >= 0; j--) {
                Alien alien = new Alien(20 + i * 50, 30 + j * 40);
                columnAliens.add(alien);
                alien.addHitListener(remover);
            }
            tempList.add(columnAliens);
        }
        return tempList;

    }

    /**
     * @param d - the DrawSurface of the GUI we'll create later.
     */
    @Override
    public void drawOn(DrawSurface d) {
        for (List<Alien> alienCol : aliensGroup) {
            for (Alien alien : alienCol) {
                alien.drawOn(d);
            }
        }
    }

    /**
     * if an alien got hit - remove it.
     *
     * @param alien alien to remove
     */
    public void removeFromGame(Block alien) {
        for (int i = 0; i < aliensGroup.size(); i++) {
            List<Alien> columnAliens = aliensGroup.get(i);
            for (int j = 0; j < columnAliens.size(); j++) {
                if (columnAliens.get(j).equals(alien)) {
                    columnAliens.remove(j);
                    if (columnAliens.isEmpty()) {
                        aliensGroup.remove(i);
                    }
                    break;
                }
            }
        }
    }

    /**
     * in charge of the Aliens' moving and shooting.
     * @param dt specifies the amount of seconds passed since the last call
     */
    @Override
    public void timePassed(double dt) {
        double dx, dy = 0;
        if (aliensGroup.size() == 0 || aliensGroup == null) {
            return;
        }
        if (speed > 0) {
            double rightMost = aliensGroup.get(aliensGroup.size() - 1).get(0)
                    .getCollisionRectangle().getUpperRight().getX();
            dx = Math.min(800 - rightMost, speed * dt);
        } else {
            double leftMost = aliensGroup.get(0).get(0).getCollisionRectangle().getUpperLeft().getX();
            dx = Math.max(-leftMost, speed * dt);
        }
        if (dx == 0) {
            dy = 30;
            speed *= -1.1;
        }
        for (List<Alien> columnAliens : aliensGroup) {
            for (Alien alien : columnAliens) {
                alien.moveOneStep((int) dx, (int) dy);
                bottomYCoordinate = Math.max(bottomYCoordinate, alien.getCollisionRectangle().getLowerLeft().getY());
            }
        }
        long time = System.currentTimeMillis();
        if (time - lastShoot > 500 && ballCreator != null) {
            Random rnd = new Random();
            int shots = rnd.nextInt(aliensGroup.size());
            Point point = aliensGroup.get(shots).get(0).getCollisionRectangle().getLowerLine().middle();
            ballCreator.bullet((int) point.getX(), (int) point.getY() + 1);
            lastShoot = time;
        }
    }

    /**
     * adding hitlisteners to each Alien such as BlockRemover BallRemover and scoreTrackingListener.
     *
     * @param hitListener HitListener
     */
    public void addHitListener(HitListener hitListener) {
        for (List<Alien> alienList : aliensGroup) {
            for (Alien alien : alienList) {
                alien.addHitListener(hitListener);
            }
        }
    }

    /**
     * adding the Aliens' bullets (Balls) to the game.
     *
     * @param gameLevel GameLevel
     */
    @Override
    public void addToGame(GameLevel gameLevel) {
        gameLevel.addSprite(this);
        ballCreator = new BallCreator() {
            @Override
            public Ball bullet(int x, int y) {
                Ball bullet = new Bullets(x, y);
                bullet.setGameEnvironment(gameLevel.getEnvironment());
                bullet.addToGame(gameLevel);
                bullet.setPlayerBullet(false);
                gameLevel.addBullet(bullet);
                return bullet;
            }
        };
    }

    /**
     * after the player lost a round (was hit) - place the aliens next to the upper left corner of the screen.
     */
    public void rePosition() {
        double mostLeft = aliensGroup.get(0).get(0).getCollisionRectangle().getLowerLeft().getX();
        double highestPos = 800;
        for (List<Alien> alienList : aliensGroup) {
            double temp = alienList.get(alienList.size() - 1).getCollisionRectangle().getUpperLeft().getY();
            if (highestPos > temp) {
                highestPos = temp;
            }
        }
        for (List<Alien> col : aliensGroup) {
            for (Alien enemy : col) {
                enemy.moveOneStep((int) -mostLeft, (int) -highestPos + 25);
            }
        }
        bottomYCoordinate = 0;
        speed = startSpeed;
    }

    /**
     * return each column as Blocks.
     *
     * @return aliens
     */
    public List<Block> getAliens() {
        List<Block> aliens = new ArrayList<>();
        for (int i = 0; i < aliensGroup.size(); i++) {
            aliens.addAll(aliensGroup.get(i));
        }
        return aliens;
    }

    /**
     * if an Alien passed the Shields line - the player lost 1 life.
     *
     * @return boolean
     */
    public boolean turnStatus() {
        if (bottomYCoordinate < 510) {
            return true;
        }
        return false;
    }
}
