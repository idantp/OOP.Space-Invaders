package spaceinvaders;
/*
 * Idan Twito
 * 311125249
 */

import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import blockandpaddle.SpaceRemover;
import geometricshapes.Point;
import geometricshapes.Rectangle;
import geometricshapes.Velocity;
import geometricshapes.Ball;
import interfaces.BallCreator;
import interfaces.Collidable;
import interfaces.Sprite;
import levelsandgame.GameLevel;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * spaceinvaders.Spacecraft describes the player in the Game. it's a geometricshapes.Rectangle which
 * implements interfaces.
 * Sprite and interfaces.Collidable.
 * it can move right al left according to the key presses.
 *
 * @ 20.04.18
 * @ last update: 21.05.18
 * @ author: Idan Twito
 */
public class Spacecraft implements Sprite, Collidable {
    private KeyboardSensor keyboard;
    private Color color;
    private Rectangle rectangle;
    private double velocity;
    private double leftBorder;
    private double rightBorder;
    private long lastShotMilSec;
    private BallCreator ballCreator;
    private List<SpaceRemover> spaceKiller;


    /**
     * the constructor of the spaceinvaders.Spacecraft.
     *
     * @param keyboard    - reading the keys from the given keyboard
     * @param color       - the Color of the spaceinvaders.Spacecraft.
     * @param rectangle   - the geometricshapes.Rectangle that describes the spaceinvaders.Spacecraft.
     * @param velocity    - the velocity that describes the spaceinvaders.Spacecraft.
     * @param leftBorder  - the X coordinate which the paddle cant pass from the left.
     * @param rightBorder - the X coordinate which the paddle cant pass from the right.
     */
    public Spacecraft(KeyboardSensor keyboard, Color color, Rectangle rectangle, double velocity,
                      double leftBorder, double rightBorder) {
        Point upperLeft = new Point(rectangle.getUpperLeft().getX(), rectangle.getUpperLeft().getY());
        this.keyboard = keyboard;
        this.color = color;
        this.velocity = velocity;
        this.leftBorder = leftBorder;
        this.rightBorder = rightBorder;
        this.rectangle = new Rectangle(upperLeft, rectangle.getWidth(), rectangle.getHeight());
        this.lastShotMilSec = 0;
        this.spaceKiller = new ArrayList<>();
    }

    /**
     * removes this Spacecraft once being hit by alien's bullet.
     * @param killer SpaceRemover
     */
    public void addPaddleRemover(SpaceRemover killer) {
        spaceKiller.add(killer);
    }

    /**
     * moving the paddle to the left.
     *
     * @param dt specifies the amount of seconds passed since the last call
     */
    public void moveLeft(double dt) {
        Point newUpperLeft;
        //makes sure the speed depends on frames per seconds
        double tempVelocity = velocity * dt;
        //and the spaceinvaders.Spacecraft might cross the left Border - make sure the paddle doesnt pass this border.
        if (this.rectangle.getUpperLeft().getX() - tempVelocity < (this.leftBorder - 20)) {
            newUpperLeft = new Point(this.leftBorder - 20, this.rectangle.getUpperLeft().getY());
            this.rectangle.setUpperLeft(newUpperLeft);
        } else {
            newUpperLeft = new Point(this.rectangle.getUpperLeft().getX() - tempVelocity,
                    this.rectangle.getUpperLeft().getY());
            //otherwise: moving the spaceinvaders.Spacecraft according to its geometricshapes.Velocity.
            this.rectangle.setUpperLeft(newUpperLeft);
        }
    }


    /**
     * moving the paddle to the right.
     *
     * @param dt specifies the amount of seconds passed since the last call
     */
    public void moveRight(double dt) {
        Point newUpperLeft;
        double tempVelocity = velocity * dt;
        //and the spaceinvaders.Spacecraft might cross the right Border - make sure the paddle doesn't pass this border.
        if (this.rectangle.getUpperRight().getX() + tempVelocity > (this.rightBorder + 20)) {
            newUpperLeft = new Point((this.rightBorder + 20) - this.rectangle.getWidth(),
                    this.rectangle.getUpperLeft().getY());
            this.rectangle.setUpperLeft(newUpperLeft);
        } else {
            newUpperLeft = new Point(this.rectangle.getUpperLeft().getX() + tempVelocity,
                    this.rectangle.getUpperLeft().getY());
            //otherwise: moving the spaceinvaders.Spacecraft according to its geometricshapes.Velocity.
            this.rectangle.setUpperLeft(newUpperLeft);
        }
    }

    /**
     * sets the player's/Spacecraft bullet/Ball.
     * @param creator BallCreator
     */
    public void setBallCreator(BallCreator creator) {
        this.ballCreator = creator;
    }

    /**
     * if time passed - see if moving is required.
     *
     * @param dt specifies the amount of seconds passed since the last call
     */
    public void timePassed(double dt) {
        //if the right arrow in the keyboard is pressed
        if (keyboard.isPressed(KeyboardSensor.RIGHT_KEY)) {
            this.moveRight(dt);
        }
        //if the left arrow in the keyboard is pressed
        if (keyboard.isPressed(KeyboardSensor.LEFT_KEY)) {
            this.moveLeft(dt);
        }
        if (keyboard.isPressed(KeyboardSensor.SPACE_KEY)) {
            long currentTime = System.currentTimeMillis();
            long delay = currentTime - 350;
            int yCoordinate = (int) rectangle.getUpperLeft().getY() - 1;
            int xCoordinate = (int) rectangle.getUpperLine().middle().getX();
            if (lastShotMilSec < delay) {
                this.lastShotMilSec = currentTime;
                this.ballCreator.bullet(xCoordinate, yCoordinate);
            }
        }
    }

    /**
     * drawing the paddle and its lines.
     *
     * @param d - the DrawSurface of the GUI of the Game create.
     */
    public void drawOn(DrawSurface d) {
        d.setColor(this.color);
        d.fillRectangle((int) this.rectangle.getUpperLeft().getX(), (int) this.rectangle.getUpperLeft().getY(),
                (int) this.rectangle.getWidth(), (int) this.rectangle.getHeight());
        d.setColor(Color.BLACK);
        d.drawRectangle((int) this.rectangle.getUpperLeft().getX(), (int) this.rectangle.getUpperLeft().getY(),
                (int) this.rectangle.getWidth(), (int) this.rectangle.getHeight());

    }

    /**
     * returning the rectangle when there was a collision.
     *
     * @return - geometricshapes.Rectangle this.rectangle
     */
    public Rectangle getCollisionRectangle() {
        return this.rectangle;
    }

    /**
     * given there was a collision of an object with this spaceinvaders.Spacecraft,
     * the function returns the new velocity
     * of the colliding object after the hit with this spaceinvaders.Spacecraft.
     *
     * @param collisionPoint  geometricshapes.Point that describes the collision point.
     * @param currentVelocity geometricshapes.Velocity - the current velocity of the colliding object.
     * @param hitter          - the geometricshapes.Ball that is involved in the this hit.
     * @return geometricshapes.Velocity newVelocity - the new velocity of the geometricshapes.Ball.
     */
    public Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity) {
        for (SpaceRemover killer : spaceKiller) {
            killer.hit();
        }
        return null;
    }

    /**
     * Add this paddle to the game.
     *
     * @param g Game
     */
    public void addToGame(GameLevel g) {
        g.addCollidable(this);
        g.addSprite(this);
    }

    /**
     * Remove this paddle to the game.
     *
     * @param g Game
     */
    public void removeFromGame(GameLevel g) {
        g.removeSprite(this);
        g.removeCollidable(this);
    }
}