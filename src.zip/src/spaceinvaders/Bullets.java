package spaceinvaders;
/*
 * Idan Twito
 * 311125249
 */

import geometricshapes.Ball;
import geometricshapes.Point;

import java.awt.Color;

/**
 * this Class describes the Aliens' Bullets (Balls) they shoot towards the player.
 */
public class Bullets extends Ball {
    /**
     * Constructor.
     *
     * @param xCoordinate the x Coordinate of the Ball's Center Points.
     * @param yCoordinate the y Coordinate of the Ball's Center Points.
     */
    public Bullets(int xCoordinate, int yCoordinate) {
        super(new Point(xCoordinate, yCoordinate), 4, Color.RED);
        super.setVelocity(0, 475);
    }
}
